package br.com.spring.olamundo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OlamundoApplication {

	public static void main(String[] args) {
		SpringApplication.run(OlamundoApplication.class, args);
	}

}
