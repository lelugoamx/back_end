package br.com.spring.olamundo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OlamundoApplicationTests {

	@Test
	void contextLoads() {
	}

}
