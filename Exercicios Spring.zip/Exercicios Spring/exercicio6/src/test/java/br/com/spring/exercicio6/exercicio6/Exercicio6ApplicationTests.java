package br.com.spring.exercicio6.exercicio6;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Exercicio6ApplicationTests {

	@Test
	void contextLoads() {
	}

}
