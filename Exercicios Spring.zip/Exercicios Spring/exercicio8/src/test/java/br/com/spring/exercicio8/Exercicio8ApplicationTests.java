package br.com.spring.exercicio8;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Exercicio8ApplicationTests {

	@Test
	void contextLoads() {
	}

}
