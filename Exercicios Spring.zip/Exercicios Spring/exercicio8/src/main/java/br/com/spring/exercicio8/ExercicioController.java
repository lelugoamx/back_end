package br.com.spring.exercicio8;

import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;

@RestController
public class ExercicioController {
	@GetMapping("/professor/{nome}/{disciplina}/{curso}")
	public String professorInfo(@PathVariable String nome, @PathVariable String disciplina,
			@PathVariable String curso) {
		return "Professor: " + nome + ", Disciplina: " + disciplina + ", Curso: " + curso;
	}

	@GetMapping("/aluno/{nome}/{idade}")
	public String alunoInfo(@PathVariable String nome, @PathVariable int idade) {
		return "Aluno: " + nome + ", Idade: " + idade + " anos";
	}

	@GetMapping("/turma/{codigo}/{periodo}")
	public String turmaInfo(@PathVariable String codigo, @PathVariable String periodo) {
		return "Turma: " + codigo + ", Período: " + periodo;
	}

	@GetMapping("/escola/{nome}/{cidade}")
	public String escolaInfo(@PathVariable String nome, @PathVariable String cidade) {
		return "Escola: " + nome + ", Cidade: " + cidade;
	}

}
