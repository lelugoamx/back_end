package br.com.spring.exercicio8;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Exercicio8Application {

	public static void main(String[] args) {
		SpringApplication.run(Exercicio8Application.class, args);
	}

}
