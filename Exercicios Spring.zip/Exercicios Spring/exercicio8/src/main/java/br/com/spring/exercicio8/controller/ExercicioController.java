package br.com.spring.exercicio8.controller;

import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;

@RestController
public class ExercicioController {
	
	@GetMapping("/professor/Rafael/TI/PWBE")
	public String professorInfo(@RequestParam String nome, @RequestParam String disciplina,
			@RequestParam String curso) {
		return "Professor: " + nome + ", Disciplina: " + disciplina + ", Curso: " + curso;
	}

	@GetMapping("/aluno/Rafael/32 ")
	public String alunoInfo(@RequestParam String nome, @RequestParam int idade) {
		return "Aluno: " + nome + ", Idade: " + idade + " anos";
	}

	@GetMapping("/turma/2MDS/Manhã")
	public String turmaInfo(@RequestParam String codigo, @RequestParam String periodo) {
		return "Turma: " + codigo + ", Período: " + periodo;
	}

	@GetMapping("/escola/Senai/São%20Carlos")
	public String escolaInfo(@RequestParam String nome, @RequestParam String cidade) {
		return "Escola: " + nome + ", Cidade: " + cidade;
	}

}
