package br.com.spring.exercicio3;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ExercicioController {

	@GetMapping("/add")
	public double addition(@RequestParam double num1, @RequestParam double num2) {
		return num1 + num2;
	}

	@GetMapping("/subtract")
	public double subtraction(@RequestParam double num1, @RequestParam double num2) {
		return num1 - num2;
	}

	@GetMapping("/multiply")
	public double multiplication(@RequestParam double num1, @RequestParam double num2) {
		return num1 * num2;
	}

	@GetMapping("/divide")
	public double division(@RequestParam double num1, @RequestParam double num2) {
		if (num2 != 0) {
			return num1 / num2;
		} else {
			return Double.POSITIVE_INFINITY;
		}
	}

}
