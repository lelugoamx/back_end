package br.com.spring.exercicio10.controller;

import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;

@RestController
public class ExercicioController {
	private final String API_URL = "https://economia.awesomeapi.com.br/json/last/USD-BRL";

	@GetMapping("/compra")
	public String getCompra() {
		return getFieldValue("bid");
	}

	@GetMapping("/venda")
	public String getVenda() {
		return getFieldValue("ask");
	}

	@GetMapping("/max")
	public String getMax() {
		return getFieldValue("high");
	}

	@GetMapping("/min")
	public String getMin() {
		return getFieldValue("low");
	}

	@GetMapping("/all")
	public String getAll() {
		return restTemplate().getForObject(API_URL, String.class);
	}

	private String getFieldValue(String field) {
		String resposta = restTemplate().getForObject(API_URL, String.class);
		if (resposta != null) {
			int comecarIndex = resposta.indexOf("\"" + field + "\":\"");
			if (comecarIndex != -1) {
				comecarIndex += field.length() + 4;
				int finalizarIndex = resposta.indexOf("\"", comecarIndex);
				if (finalizarIndex != -1) {
					return resposta.substring(comecarIndex, finalizarIndex);
				}
			}
		}
		return "N/A";
	}

	private RestTemplate restTemplate() {
		return new RestTemplate();
	}
}
