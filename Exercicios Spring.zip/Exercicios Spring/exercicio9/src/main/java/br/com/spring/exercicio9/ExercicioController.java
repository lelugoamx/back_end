package br.com.spring.exercicio9;

import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@RestController
public class ExercicioController {

	@GetMapping("/concatenar/{texto1}/{texto2}")
	public String concatenar(@PathVariable String texto1, @PathVariable String texto2) {
		return texto1 + texto2;
	}

	@GetMapping("/contar/{texto}")
	public int contarCaracteres(@PathVariable String texto) {
		return texto.length();
	}

	@GetMapping("/inverter/{texto}")
	public String inverterTexto(@PathVariable String texto) {
		return new StringBuilder(texto).reverse().toString();
	}

	@GetMapping("/maiuscula/{texto}")
	public String converterParaMaiuscula(@PathVariable String texto) {
		return texto.toUpperCase();
	}
}
