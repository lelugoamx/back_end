package br.com.spring.exercicio9.controller;

import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;

@RestController
public class ExercicioController {

	@GetMapping("/concatenar/{texto1}/{texto2}")
	public String concatenar(@RequestParam String texto1, @RequestParam String texto2) {
		return texto1 + texto2;
	}

	@GetMapping("/contar/{texto}")
	public int contarCaracteres(@RequestParam String texto) {
		return texto.length();
	}

	@GetMapping("/inverter/{texto}")
	public String inverterTexto(@RequestParam String texto) {
		return new StringBuilder(texto).reverse().toString();
	}

	@GetMapping("/maiuscula/{texto}")
	public String converterParaMaiuscula(@RequestParam String texto) {
		return texto.toUpperCase();
	}
}
