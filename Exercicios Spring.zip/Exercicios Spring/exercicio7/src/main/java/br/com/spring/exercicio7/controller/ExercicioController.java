package br.com.spring.exercicio7.controller;

import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

@RestController
public class ExercicioController {

	@GetMapping("/verificar")
	public String verificarParOuImpar(@RequestParam int numero) {
		if (numero % 2 == 0) {
			return "O número " + numero + " é par.";
		} else {
			return "O número " + numero + " é ímpar.";
		}
	}
}
