package br.com.spring.exercicio4.controller;

import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

@RestController
public class ExercicioController {

	@GetMapping("/cambio")
    public String converterMoeda(@RequestParam String nome, @RequestParam double valor) {
        if ("real".equalsIgnoreCase(nome)) {
            double valorEmDolar = valor / 5.0;
            return "Você tem " + valor + " reais ou " + valorEmDolar + " dólares";
        } else if ("dolar".equalsIgnoreCase(nome)) {
            double valorEmReal = valor * 5.0;
            return "Você tem " + valor + " dólares ou " + valorEmReal + " reais";
        } else {
            return "Moeda não suportada";
        }
    }
}
