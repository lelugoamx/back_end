package br.com.spring.exercicio4;


@SpringBootApplication
public class Exercicio4Application {

	public static void main(String[] args) {
		SpringApplication.run(Exercicio4Application.class, args);
	}

}
