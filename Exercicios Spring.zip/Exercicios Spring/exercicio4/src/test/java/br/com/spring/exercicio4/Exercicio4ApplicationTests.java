package br.com.spring.exercicio4;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Exercicio4ApplicationTests {

	@Test
	void contextLoads() {
	}

}
