package br.com.spring.exercicio10;

import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;

@RestController
public class ExercicioController {
	private final String API_URL = "https://economia.awesomeapi.com.br/json/last/USD-BRL";

	@GetMapping("/compra")
	public String getCompra() {
		return getFieldValue("bid");
	}

	@GetMapping("/venda")
	public String getVenda() {
		return getFieldValue("ask");
	}

	@GetMapping("/max")
	public String getMax() {
		return getFieldValue("high");
	}

	@GetMapping("/min")
	public String getMin() {
		return getFieldValue("low");
	}

	@GetMapping("/all")
	public String getAll() {
		return restTemplate().getForObject(API_URL, String.class);
	}

	private String getFieldValue(String field) {
		String response = restTemplate().getForObject(API_URL, String.class);
		// Parse JSON response to extract the specified field
		if (response != null) {
			int startIndex = response.indexOf("\"" + field + "\":\"");
			if (startIndex != -1) {
				startIndex += field.length() + 4; // Adjust the start index
				int endIndex = response.indexOf("\"", startIndex);
				if (endIndex != -1) {
					return response.substring(startIndex, endIndex);
				}
			}
		}
		return "N/A";
	}

	private RestTemplate restTemplate() {
		return new RestTemplate();
	}
}
