package br.com.spring.exercicio10;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Exercicio10ApplicationTests {

	@Test
	void contextLoads() {
	}

}
