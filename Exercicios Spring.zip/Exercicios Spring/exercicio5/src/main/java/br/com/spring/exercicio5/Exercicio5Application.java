package br.com.spring.exercicio5;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Exercicio5Application {

	public static void main(String[] args) {
		SpringApplication.run(Exercicio5Application.class, args);
	}

}
