package br.com.spring.exercicio5;

import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

@RestController
public class ExercicioController {

	@GetMapping("/inverter")
	public String inverterString(@RequestParam String texto) {
		return new StringBuilder(texto).reverse().toString();
	}

	@GetMapping("/contar")
	public int contarCaracteres(@RequestParam String texto) {
		return texto.length();
	}

	@GetMapping("/converter/minusculas")
	public String converterParaMinusculas(@RequestParam String texto) {
		return texto.toLowerCase();
	}

	@GetMapping("/converter/maiusculas")
	public String converterParaMaiusculas(@RequestParam String texto) {
		return texto.toUpperCase();
	}

}
