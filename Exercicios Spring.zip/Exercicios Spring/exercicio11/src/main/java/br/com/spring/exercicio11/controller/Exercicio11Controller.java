package br.com.spring.exercicio11.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
public class Exercicio11Controller{
	private final String API_URL = "https://viacep.com.br/"; 
	
	@GetMapping("/cep/{cep}")
	public String CEP(@PathVariable String cep) {
		return restTemplate().getForObject(API_URL + cep + "/json/",String.class);
	}
	
	@GetMapping("/logadouro/{cep}")
	public String logadouro(@PathVariable String cep) {
		String resposta = restTemplate().getForObject(API_URL + cep + "/json/",String.class);
		return getFieldValue(resposta,"logadouro");
	}
		
		
		private String getFieldValue(String resposta, String campo) {
			if (resposta != null) {
				int comecarIndex = resposta.indexOf("\"" + campo + "\":\"");
				if (comecarIndex != -1) {
					comecarIndex += campo.length() + 4;
					int finalizarIndex = resposta.indexOf("\"", comecarIndex);
					if (finalizarIndex != -1) {
						return resposta.substring(comecarIndex, finalizarIndex);
					}
				}
			}
			return "N/A";
		}

		private RestTemplate restTemplate() {
			return new RestTemplate();
		}
	

	
}
