package br.com.spring.exercicio11.controller;



@RestController
public class Exercicio11Controller{
	
	@GetMapping
	public String casa() {
		return "Ola mundo!";
	}
}
