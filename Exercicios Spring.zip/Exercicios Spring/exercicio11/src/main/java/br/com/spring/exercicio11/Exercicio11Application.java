package br.com.spring.exercicio11;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Exercicio11Application {

	public static void main(String[] args) {
		SpringApplication.run(Exercicio11Application.class, args);
	}

}
