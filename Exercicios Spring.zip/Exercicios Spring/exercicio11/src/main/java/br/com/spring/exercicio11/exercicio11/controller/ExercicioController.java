package br.com.spring.exercicio11.exercicio11.controller;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;

@RestController
@RequestMapping("/cep")
public class ExercicioController {

    private final String VIA_CEP_URL = "https://viacep.com.br/ws/";

    @GetMapping("/{cep}")
    public String getCepInfo(@PathVariable String cep) {
        String url = VIA_CEP_URL + cep + "/json/";
        return restTemplate().getForObject(url, String.class);
    }

    @GetMapping("/logradouro/{cep}")
    public String getCepLogradouro(@PathVariable String cep) {
        String url = VIA_CEP_URL + cep + "/json/";
        String resposta = restTemplate().getForObject(url, String.class);
        try {
            ObjectMapper mapper = new ObjectMapper();
            JsonNode root = mapper.readTree(resposta);

            if (root.has("logradouro")) {
                return root.get("logradouro").asText();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return "N/A";
    }

    @GetMapping("/uf/{cep}")
    public String getCepUf(@PathVariable String cep) {
        String url = VIA_CEP_URL + cep + "/json/";
        String resposta = restTemplate().getForObject(url, String.class);
        try {
            ObjectMapper mapper = new ObjectMapper();
            JsonNode root = mapper.readTree(resposta);

            if (root.has("uf")) {
                return root.get("uf").asText();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return "N/A";
    }

    @GetMapping("/localidade/{cep}")
    public String getCepLocalidade(@PathVariable String cep) {
        String url = VIA_CEP_URL + cep + "/json/";
        String resposta = restTemplate().getForObject(url, String.class);
        try {
            ObjectMapper mapper = new ObjectMapper();
            JsonNode root = mapper.readTree(resposta);

            if (root.has("localidade")) {
                return root.get("localidade").asText();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return "N/A";
    }

    @GetMapping("/ibge/{cep}")
    public String getCepIbge(@PathVariable String cep) {
        String url = VIA_CEP_URL + cep + "/json/";
        String resposta = restTemplate().getForObject(url, String.class);
        try {
            ObjectMapper mapper = new ObjectMapper();
            JsonNode root = mapper.readTree(resposta);

            if (root.has("ibge")) {
                return root.get("ibge").asText();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return "N/A";
    }

    private RestTemplate restTemplate() {
        return new RestTemplate();
    }
}
